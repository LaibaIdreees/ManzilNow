import React from 'react'

export default function Feedback() {
    return (
        <>
            <div className='  overflow-x-auto  rounded-md sm:w-full w-[25rem] '>

                <table className='text-sm text-left rtl:text-left w-full'>
                    <thead className='text-xs  uppercase  bg-meta-2 text-meta-4'>
                        <tr className=' '>
                            <th scope="col" className="px-6 py-3">Name</th>
                            <th scope="col" className="px-6 py-3">Phone</th>
                            <th scope="col" className="px-6 py-3">Driver Name</th>
                            <th scope="col" className="px-6 py-3">Stars</th>
                            <th scope="col" className="px-6 py-3">Comment</th>

                        </tr>
                    </thead>
                    <tbody className=' justify-between bg-white'>
                        {



                        }


                    </tbody>
                </table>
            </div>

        </>
    )
}

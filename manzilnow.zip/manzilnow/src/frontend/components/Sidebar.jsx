// Import necessary modules from both files
import React, { useState, useEffect, useRef } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import Swal from 'sweetalert2';
import Logo from '../../images/logo.png';
import { FaUsers, FaCarRear } from "react-icons/fa6";
import { ImUser } from "react-icons/im";
import { FaCreditCard, FaMoneyBillAlt  } from "react-icons/fa";
import {  MdDashboard  } from "react-icons/md";
import { TbAlertCircleFilled } from "react-icons/tb";
import { RiLogoutCircleFill } from "react-icons/ri";
import { RxGear } from 'react-icons/rx';

const SidebarFunc = (props) => {
    const role = sessionStorage.getItem('role');
    const name = sessionStorage.getItem('name');
    var SidebarArray = [];
    if (role === 'super-admin') {

        SidebarArray = [
            {
                name: 'Dashboard',
                icon: <MdDashboard  />,
                link: 'dashboard',
            },
            {
                name: 'Admins',
                icon: <FaUsers />,
                link: 'admins',
            },
            {
                name: 'Drivers',
                icon: <FaCarRear />,
                link: 'drivers',
            },
            {
                name: 'Passengers',
                icon: <ImUser />,
                link: 'passengers',
            },
            {
                name: 'Payments',
                icon: <FaCreditCard />,
                link: 'payments',
            },
            {
                name: 'Fair Calculation',
                icon: <FaMoneyBillAlt />,
                link: 'faricalculation',
            },
 
            {
                name: 'Complaints',
                icon: <TbAlertCircleFilled />,
                link: 'complaints',
            }

        ];

    }
    else if (role === 'fair-management') {
        SidebarArray = [
            {
                name: 'Dashboard',
                icon: <MdDashboard  />,
                link: 'dashboard',
            },
            {
                name: 'Drivers',
                icon: <FaCarRear />,
                link: 'drivers',
            },
            {
                name: 'Payments',
                icon: <FaCreditCard />,
                link: 'payments',
            },
            {
                name: 'Fair Calculation',
                icon: <FaMoneyBillAlt />,
                link: 'faricalculation',
            }

        ];
    }
    else if (role === 'customer-support') {
        SidebarArray = [
            {
                name: 'Dashboard',
                icon: <MdDashboard  />,
                link: 'dashboard',
            },
    
            {
                name: 'Complaints',
                icon: <TbAlertCircleFilled />,
                link: 'complaints',
            }
        ];

    }
    else if (role === 'driver-management') {
        SidebarArray = [
            {
                name: 'Dashboard',
                icon: <MdDashboard  />,
                link: 'dashboard',
            },
            {
                name: 'Drievers',
                icon: <FaCarRear />,
                link: 'drivers',
            }
        ];
    }


    const [sidebarOpen, setSidebarOpen] = useState(false);

    const sidebar = useRef(null);
    const trigger = useRef(null);
    const location = useLocation();
    useEffect(() => {
        setSidebarOpen(false);
    }, [location]);

    const handleLogout = () => {
        Swal.fire({
            title: 'Are you sure?',
            text: 'You want to logout?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, logout!',
            cancelButtonText: 'No, cancel!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                sessionStorage.removeItem('token');
                sessionStorage.removeItem('role');
                sessionStorage.removeItem('name');
                return window.location.href = '/';
            }
        });
    };



    return (
        <>
            <aside
                ref={sidebar}
                className={`absolute left-0 top-0 z-9999 flex h-screen w-72.5 flex-col overflow-y-hidden bg-black duration-300 ease-linear lg:static lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'
                    }`}
            >
                {/* <!-- SIDEBAR HEADER --> */}
                <div className="flex items-center  gap-2 px-6 py-5.5 lg:py-6.5 ">
                    <div>
                           <NavLink to="/">
                        <img src={Logo} alt="Logo" 
                        className="w-10 h-10 lg:w-11 lg:h-11"
                        />
                    </NavLink>
                    </div>
                 
                    <div className=" italic font-light text-gray">
                        MANZIL NOW
                        </div>

                  
                </div>
                {/* <!-- SIDEBAR HEADER --> */}

                <div className="no-scrollbar  border-t flex flex-col overflow-y-auto duration-300 ease-linear">
                    {/* <!-- Sidebar Menu --> */}
                    <nav className="mt-5 py-4 px-4 lg:mt-9 lg:px-6 flex flex-col gap-32">
                        {/* <!-- Menu Group --> */}
                        <div>
                            <h3 className="mb-4 ml-4 text-sm font-semibold text-bodydark2">
                                MENU
                            </h3>

                            <ul className="mb-6 flex flex-col gap-1.5">
                                {SidebarArray.map((item, index) => (
                                    <li key={index}>
                                        <div
                                     
                                            onClick={() => props.setLink(item.link)}
                                            className="group cursor-pointer relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 "
                                            activeClassName="text-primary"
                                        > 
                                            {item.icon}
                                            <span>{item.name}</span>
                                        </div>
                                    </li>
                                ))}
                            </ul>


                        </div>
                        {/* <!-- Menu Group --> */}

                        {/* <!-- Logout --> */}
                        <div className="">
                            <div
                                onClick={handleLogout}
                                className="group cursor-pointer relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 "
                            >
                                <RiLogoutCircleFill />
                                <span>Logout</span>
                            </div>
                            <div
                                className="group cursor-pointer relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 "

                             onClick={() => props.setLink('settings')}
                            >
                                <RxGear />
                                <span>Setting</span>
                            </div>
                        </div>


                    </nav>
                    {/* <!-- Sidebar Menu --> */}
                </div>
            </aside>
        </>
    );
};

export default SidebarFunc;

import React, { useEffect, useState } from 'react'
import Swal from 'sweetalert2';

export default function Passengers() {
    const [loading, setLoading] = useState(true);
    const [passengers, setPassengers] = useState([]);
    const [reasonModal, setReasonModal] = useState(false);

    const [filterCriteria, setFilterCriteria] = useState({
        gender: '',
        restricted: ''
    });
    const [showFilterMenu, setShowFilterMenu] = useState(false);
    const[filterClicked, setFilterClicked] = useState(false);


    const fetchPassengers = async () => {
        try {
            const response = await fetch('http://localhost:4000/getPassengers');
            if (!response.ok) {
                throw new Error('Failed to fetch passengers');
            }

            const data = await response.json();

            if (data && data.passengers) {
                setPassengers(data.passengers);
            } else {
                setPassengers([]);
            }
        } catch (error) {
            console.error('Error fetching passengers:', error.message);
        }
        finally {
            setLoading(false);
        }
    };

    const changeRestrict = async (id, restrict) => {
        if (restrict === true && reasonModal === false) {
            setReasonModal(true);

        }

        Swal.fire({
            title: 'Are you sure?',
            text: `You are about to change the passenger restriction to ${restrict ? `'YES'` : `'NO'`}.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
        }).then(async (result) => {
            if (result.isConfirmed) {
                try {
                    const response = await fetch('http://localhost:4000/changeRestrict', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ id, restricted: restrict }),
                    });

                    if (!response.ok) {
                        throw new Error('Failed to change restrict');
                    }

                    const data = await response.json();

                    if (data && data.success) {
                        const newPassengers = passengers.map((passenger) => {
                            if (passenger.id === id) {
                                return { ...passenger, restricted: restrict };
                            }

                            return passenger;
                        });

                        setPassengers(newPassengers);
                        Swal.fire('Success', 'Restrict status changed successfully', 'success');
                    }
                } catch (error) {
                    console.error('Error changing restrict:', error.message);
                }
            }
        });

    };

    useEffect(() => {
        fetchPassengers();
    }
        , []);

        
    const handleFilterChange = (criteria, value) => {
        setFilterCriteria({ ...filterCriteria, [criteria]: value });
    };

    const filteredPassengers = passengers.filter(passenger => {
        let match = true;
        // Convert filterCriteria.restricted to a boolean variable
        const isRestricted = filterCriteria.restricted === 'Yes';
    
        if (filterCriteria.gender && passenger.gender !== filterCriteria.gender) {
            match = false;
        }
        if (filterCriteria.restricted && passenger.restricted !== isRestricted) {
            match = false;
        }
        return match;
    });
    

    // handle filter icon click
    const handleFilterIconClick = () => {
        setFilterClicked(!filterClicked);
        setShowFilterMenu(!showFilterMenu);
    };


    return (
        <>
         <div className="relative">
                <button className="absolute -top-10 right-0 p-2 bg-primary rounded-md" onClick={handleFilterIconClick}>
                    {
                        filterClicked ? (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
                            </svg>
                        )
                    }
                </button>
                {/* Filter Dropdown Menu */}
                {showFilterMenu && (
                    <div className="absolute z-99999 -top-1 right-9 bg-white border p-4 rounded shadow w-60">
                        {/* Gender Filter */}
                        <div className='mb-2'>
                            <label className="block ">Gender</label>
                            <select className="border p-2 rounded w-full" value={filterCriteria.gender} onChange={(e) => handleFilterChange('gender', e.target.value)}>
                                <option value="">All</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
               
                        <div className='mb-2'>
                            <label className="block">Restricted</label>
                            <select className="border p-2 rounded w-full" value={filterCriteria.restricted} onChange={(e) => handleFilterChange('restricted', e.target.value)} >
                                <option value="">All</option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                            
                        </div>
                        {/* clear all */}
                        <div>
                            <button
                                onClick={() => {
                                    setFilterCriteria({ 
                                        gender: '',
                                        restricted: ''
                                    });
                                }
                                }
                                className='text-sm mt-2 border border-meta-5 p-2 rounded-full'
                            >
                                Clear All
                            </button>
                            </div>

                    </div>
                )}
            </div>
            


            <div className=' rounded-md sm:w-full w-[25rem]'>

                {

                    loading ? (
                        <div className="flex justify-center items-center">
                            <div className="mt-4 animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                        </div>
                    ) : (
                        <>
                        {
                            filteredPassengers.length > 0 ? (
                            <table className='animated fadeInUp text-sm text-left rtl:text-left w-full'>
                                <thead className='text-xs  uppercase  bg-meta-2 text-meta-4'>
                                    <tr className=' '>
                                        <th scope="col" className="px-6 py-3">Name</th>
                                        <th scope="col" className="px-6 py-3">Email</th>
                                        <th scope="col" className="px-6 py-3">Phone</th>
                                        <th scope="col" className="px-6 py-3">Gender</th>
                                        <th scope="col" className="px-6 py-3">Photo</th>
                                        <th scope="col" className="px-6 py-3">Restricted</th>


                                    </tr>
                                </thead>
                                <tbody className=' justify-between bg-white'>
                                    {
                                        filteredPassengers.map((passenger, index) => (
                                            <tr key={index} className='border-meta-9 border-b '>
                                                <td className="px-6 py-4 text-left ">{passenger.display_name + ' ' + passenger.last_name}</td>
                                                <td className="px-6 py-4 text-left ">{passenger.email}</td>
                                                <td className="px-6 py-4 text-left ">{passenger.phone_number}</td>
                                                <td className="px-6 py-4 text-left ">{passenger.gender}</td>
                                                <td className="px-6 py-4 text-left ">
                                                    <img src={passenger.photo_url} alt={passenger.firstName + passenger.lastName} className='w-10 h-10 rounded-full' />
                                                </td>
                                                <td className={`px-6 py-4 text-left`}>
                                                    <button

                                                        onClick={() => changeRestrict(passenger.id, !passenger.restricted)}
                                                        className={` ${passenger.restricted ? 'bg-meta-1' : 'bg-meta-3'} text-white px-3 py-2 rounded-md
                                                  `}>
                                                        {passenger.restricted ? 'Yes' : 'No'}
                                                    </button>
                                                </td>
                                            </tr>
                                        ))
                                    }


                                </tbody>
                            </table>
                        ) : (
                            <div className='flex justify-center items-center h-96'>
                                <h1 className='text-2xl text-black'>No Passengers found</h1>
                            </div>
                        )
}
                        </>

                    )
                }

            </div>



        </>
    )
}

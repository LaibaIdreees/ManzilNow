import React, { useState, useEffect } from 'react'
import { FaCommentAlt } from 'react-icons/fa';
import CountUp from 'react-countup';
 
const Complaints = () => {

  const [complaintCount, setComplaintCount] = useState(0);

    const fetchComplaints = async () => {
      try {
          const response = await fetch('http://localhost:4000/getComplaints');
          if (!response.ok) {
              throw new Error('Failed to fetch complaints');
          }

          const data = await response.json();

          if (data && data.complaintCount) {
              setComplaintCount(data.complaintCount);
          } else {
              setComplaintCount([]);
          }
      } catch (error) {
          console.error('Error fetching complaints:', error.message);
      }
  };
    useEffect(()=>{
      fetchComplaints();
    },[]);
    return (
     
      <div className=" flex  items-center justify-around  rounded-sm border border-stroke bg-white py-10 px-7.5 shadow-default h-full">
        <div className='flex items-center justify-between'>
          <div className="flex h-18 w-16 items-center justify-center rounded-md bg-meta-2 ">
            <FaCommentAlt className="text-4xl text-primary" />
          </div>
        
        </div>
  
        <div className="mt-4 flex flex-col items-center">
            <h4 className="text-title-lg font-bold text-black ">
              <CountUp end={complaintCount} duration={2} />
            </h4>
            <div>
            <span className=" font-medium">Total Complaints</span>
          </div>
        </div>
      </div>
    );
  };
  
  export default Complaints;
  
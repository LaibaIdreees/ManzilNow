import React, { useState, useEffect } from 'react';
import { IoNotifications } from 'react-icons/io5';
import Dashboard from '../../pages/Dashboard';
const PendingDriverApproval = () => {
    const [pendingDriversCount, setPendingDriversCount] = useState(0);
    const [pendingDrivers, setPendingDrivers] = useState([]);

    const fetchPendingDrivers = async () => {
        try {
            const response = await fetch('http://localhost:4000/getDrivers');
            if (!response.ok) {
                throw new Error('Failed to fetch drivers');
            }
            const data = await response.json();
            if (data && data.drivers) {
                const filteredDrivers = Object.values(data.drivers).filter(driver => driver.Status === 'Pending');
                setPendingDrivers(filteredDrivers);
                setPendingDriversCount(filteredDrivers.length);
            } else {
                setPendingDrivers([]);
                setPendingDriversCount(0);
            }
        } catch (error) {
            console.error('Error fetching drivers:', error.message);
        }
    };

    useEffect(() => {
        fetchPendingDrivers();
    }, []);

    return (
        <div
        onClick={() => {
            <Dashboard  />
        }
        }
         className="rounded-sm border border-stroke bg-white py-6 px-7.5 shadow-default">
  
            <div className="mt-4 flex items-center justify-between">
                <div>
                    <h4 className="text-title-sm font-bold text-black">
                        {pendingDriversCount > 0 ? `Pending Drivers For Approval` : 'No Pending Drivers'}
                    </h4>
                </div>
                <div className=' flex flex-col -space-y-7'>
                    <IoNotifications className={`text-4xl  justify-center items-center 
                    ${pendingDriversCount > 0 ? 'text-meta-1' : 'text-meta-4'}
                    `} />
                    <span className='ml-[0.82rem] font-bold  text-sm text-white'> {pendingDriversCount}</span>
                </div>
            </div>
            {pendingDriversCount > 0 && (
                
                <div className="px-4 py-2 rounded-lg bg-meta-2 mt-4 ">
                <table className="mt-4 w-full text-meta-4 ">
                    <thead>
                        <tr>
                            <th className="text-left">Name</th>
                            <th className="text-left">Email</th>
                            <th className="text-left">Phone</th>
                            <th className="text-left">Gender</th>
                        </tr>
                    </thead>
                    <tbody>
                        {pendingDrivers.map(driver => (
                            <tr className=' '  key={driver.driverId}>
                                <td className=' py-2'>{driver.display_name}</td>
                                <td className=' py-2'>{driver.email}</td>
                                <td className=' py-2'>{driver.phone_number}</td>
                                <td className=' py-2'>{driver.gender}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            )}
        </div>
    );
};

export default PendingDriverApproval;

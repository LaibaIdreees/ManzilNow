import React, { useState, useEffect } from 'react'
import CountUp from 'react-countup';
import {  FaCircleCheck } from 'react-icons/fa6';
 
const Rides = () => {

  const [ridesCount, setRidesCount] = useState(0);

    const fetchRides = async () => {
      try {
          const response = await fetch('http://localhost:4000/getCompletedRide');
          if (!response.ok) {
              throw new Error('Failed to fetch complaints');
          }

          const data = await response.json();

          if (data && data.rideCount) {
              setRidesCount(data.rideCount);
          } else {
              setRidesCount([]);
          }
      } catch (error) {
          console.error('Error fetching complaints:', error.message);
      }
  };
    useEffect(()=>{
      fetchRides();
    },[]);
    return (
     
      <div className=" flex  items-center justify-around  rounded-sm border border-stroke bg-white py-10 px-7.5 shadow-default h-full">
        <div className='flex items-center justify-between'>
          <div className="flex h-18 w-16 items-center justify-center rounded-md bg-meta-2 ">
            <FaCircleCheck className="text-4xl text-primary" />

          </div>
        
        </div>
  
        <div className="mt-4 flex flex-col items-center">
            <h4 className="text-title-lg font-bold text-black ">
              <CountUp end={ridesCount} duration={2} />
            </h4>
            <div>
            <span className=" font-medium">Completed Rides</span>
          </div>
        </div>
      </div>
    );
  };
  
  export default Rides;
  
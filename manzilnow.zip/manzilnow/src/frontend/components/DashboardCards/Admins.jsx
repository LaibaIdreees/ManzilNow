import React, { useState, useEffect } from 'react'
import { FaUsers } from "react-icons/fa6";
import CountUp from 'react-countup';
const Admins = () => {

  const [adminsCount, setAdminsCount] = useState([]);

  const fetchAdmins = async () => {
    try {
      const response = await fetch('http://localhost:4000/getAllAdmins');
      if (!response.ok) {
        throw new Error('Failed to fetch drivers');
      }

      const data = await response.json();

      if (data && data.adminCount) {
        setAdminsCount(data.adminCount);
      }
      else {
        setAdminsCount([]);
      }
    } catch (error) {
      console.error('Error fetching admins:', error.message);
    }
  };

  useEffect(() => {
    fetchAdmins();

  }, []);
  return (
    <div className=" flex  items-center justify-around  rounded-sm border border-stroke bg-white py-6 px-7.5 shadow-default h-full">
      <div className='flex items-center justify-between'>
        <div className="flex h-18 w-16 items-center justify-center rounded-md bg-meta-2 ">
          <FaUsers className="text-4xl text-primary" />
        </div>
      
      </div>

      <div className="mt-4 flex flex-col items-center">
          <h4 className="text-title-lg font-bold text-black ">
            <CountUp end={adminsCount} duration={2} />
          </h4>
          <div>
          <span className=" font-medium">Total Admins</span>
        </div>
      </div>
    </div>
  );
};

export default Admins;

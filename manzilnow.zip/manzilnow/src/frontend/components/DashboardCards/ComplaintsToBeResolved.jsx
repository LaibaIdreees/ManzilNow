import React, { useState, useEffect, useCallback } from 'react';
import { IoNotifications } from 'react-icons/io5';

const ComplaintsToBeResolved = () => {
    const [pendingComplainstCount, setPendingComplaintsCount] = useState(0);
    const [pendingComplaints, setPendingComplaints] = useState([]);
    const [passengerNames, setPassengerNames] = useState([]);
    const [driverNames, setDriverNames] = useState([]);
    // const [driverPhoneNumbers, setDriverPhoneNumbers] = useState([]);

    const getPassengerById = async (id) => {
        try {
            const response = await fetch(`http://localhost:4000/getPassengerById?id=${id}`);
            if (!response.ok) {
                throw new Error('Failed to fetch passenger');
            }
            const data = await response.json();
            if (data && data.passenger) {
                return data.passenger.firstName + ' ' + data.passenger.lastName;
            } else {
                return null;
            }
        } catch (error) {
            console.error('Error fetching passenger:', error.message);
            return null;
        }
    };

    const getDriverById = async (id) => {
        try {
            const response = await fetch(`http://localhost:4000/getDriverById?id=${id}`);
            if (!response.ok) {
                throw new Error('Failed to fetch driver');
            }
            const data = await response.json();
            if (data && data.driver) {
                return data.driver.firstName + ' ' + data.driver.lastName;
            } else {
                return null;
            }
        } catch (error) {
            console.error('Error fetching driver:', error.message);
            return null;
        }
    };

    // const getDriverPhoneNumberById = async (id) => {
    //     try {
    //         const response = await fetch(`http://localhost:4000/getDriverPhoneNumberById?id=${id}`);
    //         if (!response.ok) {
    //             throw new Error('Failed to fetch driver phone number');
    //         }
    //         const data = await response.json();
    //         if (data && data.phoneNumber) {
    //             return data.phoneNumber;
    //         } else {
    //             return null;
    //         }
    //     } catch (error) {
    //         console.error('Error fetching driver phone number:', error.message);
    //         return null;
    //     }
    // };

    const fetchComplaints = async () => {
        try {
            const response = await fetch('http://localhost:4000/getComplaints');
            if (!response.ok) {
                throw new Error('Failed to fetch complaints');
            }

            const data = await response.json();

            if (data && data.complaints) {
                const filteredComplaints = Object.values(data.complaints).filter(complaint => complaint.Status === 'Pending');
                setPendingComplaints(filteredComplaints);
                setPendingComplaintsCount(filteredComplaints.length);
            } else {
                setPendingComplaints([]);
                setPendingComplaintsCount(0);
            }
        } catch (error) {
            console.error('Error fetching complaints:', error.message);
        }
    };

    const fetchPassengerNamesForComplaints = useCallback(async () => {
        try {
            const passengerNames = await Promise.all(pendingComplaints.map(async (complaint) => {
                const passengerName = await getPassengerById(complaint.passengerId);
                return passengerName;
            }));
            setPassengerNames(passengerNames);
        } catch (error) {
            console.error('Error fetching passenger names for complaints:', error.message);
        }
    }, [pendingComplaints]);

    const fetchDriverNamesForComplaints = useCallback(async () => {
        try {
            const driverNames = await Promise.all(pendingComplaints.map(async (complaint) => {
                const driverName = await getDriverById(complaint.driverId);
                return driverName;
            }));
            setDriverNames(driverNames);
        } catch (error) {
            console.error('Error fetching driver names for complaints:', error.message);
        }
    }, [pendingComplaints]);

    // const fetchDriverPhoneNumbersForComplaints = useCallback(async () => {
    //     try {
    //         const driverPhoneNumbers = await Promise.all(pendingComplaints.map(async (complaint) => {
    //             const driverPhoneNumber = await getDriverPhoneNumberById(complaint.driverId);
    //             return driverPhoneNumber;
    //         }));
    //         setDriverPhoneNumbers(driverPhoneNumbers);
    //     } catch (error) {
    //         console.error('Error fetching driver phone numbers for complaints:', error.message);
    //     }
    // }, [pendingComplaints]);

    useEffect(() => {
        fetchComplaints();
        //fetchPassengerNamesForComplaints();
        //fetchDriverNamesForComplaints();
        //fetchDriverPhoneNumbersForComplaints();
    }, [
]);

    return (
        <div className="rounded-sm border border-stroke bg-white py-6 px-7.5 shadow-default">
            <div className="mt-4 flex items-center justify-between">
                <div>
                    <h4 className="text-title-sm font-bold text-black">
                        {pendingComplainstCount > 0 ? `Complaints to be Resolved` : 'No Complaints to be Resolved'}
                    </h4>
                </div>
                <div className='flex flex-col -space-y-7'>
                    <IoNotifications className={`text-4xl  justify-center items-center 
                    ${pendingComplainstCount > 0 ? 'text-meta-1' : 'text-meta-4'}
                    `} />
                    <span className='ml-[0.82rem] font-bold  text-sm text-white'> {pendingComplainstCount}</span>
                </div>
            </div>
            {pendingComplainstCount > 0 && (
                <div className="px-4 py-2 rounded-lg bg-meta-2 mt-4 ">
                    <table className="mt-4 w-full text-meta-4 ">
                        <thead>
                            <tr>
                                <th className="text-left">Name</th>
                                <th className="text-left">User</th>
                                <th className="text-left">Phone</th>
                            </tr>
                        </thead>
                        <tbody>
                            {pendingComplaints.map((complaint, index) => (
                                <tr key={complaint.id} className='border-meta-9 border-b'>
                         
                                    <td className="px-2">{complaint.name}</td>
                                    <td className="py-2">{complaint.user}</td>
                                    <td className="py-2">{complaint.phone}</td>
                                    {/* <td className="py-2">{driverPhoneNumbers[index]}</td> */}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

export default ComplaintsToBeResolved;

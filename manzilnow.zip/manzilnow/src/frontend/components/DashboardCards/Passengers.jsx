import React, { useState, useEffect } from 'react'
import { FaUser } from 'react-icons/fa';
import CountUp from 'react-countup';

const Passengers = () => {

    const [passengerCount, setPassengerCount] = useState([]);
    
    const fetchPassengers = async () => {
      try {
          const response = await fetch('http://localhost:4000/getPassengers');
          if (!response.ok) {
              throw new Error('Failed to fetch passengers');
          }

          const data = await response.json();

          if (data && data.passengerCount) {
              setPassengerCount(data.passengerCount);
          } else {
              setPassengerCount([]);
          }
      } catch (error) {
          console.error('Error fetching passengers:', error.message);
      }
  };
    
    useEffect(()=>{
        fetchPassengers();

    },[]);
    return (
  
      <div className=" flex  items-center justify-around  rounded-sm border border-stroke bg-white py-8 px-7.5 shadow-default h-full">
        <div className='flex items-center justify-between'>
          <div className="flex h-18 w-16 items-center justify-center rounded-md bg-meta-2 ">
            <FaUser className="text-4xl text-primary" />
          </div>
        
        </div>
  
        <div className="mt-4 flex flex-col items-center">
            <h4 className="text-title-lg font-bold text-black ">
              <CountUp end={passengerCount} duration={2} />
            </h4>
            <div>
            <span className=" font-medium">Total Passengers</span>
          </div>
        </div>
      </div>

    );
  };
  
  export default Passengers;
  
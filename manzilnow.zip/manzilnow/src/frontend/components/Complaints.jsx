import React, { useState, useEffect } from 'react'
import Swal from 'sweetalert2';
export default function Complaints() {
  const role = sessionStorage.getItem('role');
  const [complaints, setComplaints] = useState([]);
  const [selectedComplaint, setSelectedComplaint] = useState({
    id: '',
    Status: '',
  });
  const [updatedStatus, setUpdatedStatus] = useState({ status: '' });
  const [filterCriteria, setFilterCriteria] = useState({
    user:'',
    Status: ''
});
const [showFilterMenu, setShowFilterMenu] = useState(false);

const[filterClicked, setFilterClicked] = useState(false);
  const fetchComplaints = async () => {
    try {
      const response = await fetch('http://localhost:4000/getComplaints');
      if (!response.ok) {
        throw new Error('Failed to fetch complaints');
      }

      const data = await response.json();

      if (data && data.complaints) {
        setComplaints(data.complaints);
      } else {
        setComplaints([]);
      }
    } catch (error) {
      console.error('Error fetching complaints:', error.message);
    }
  };

const handleFilterChange = (criteria, value) => {
  setFilterCriteria({ ...filterCriteria, [criteria]: value });
};

  const handleUpdateStatus = async () => {
    if(updatedStatus.status === ''){
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Please change the status to update it.',
      });
      return;
    }
    try {
      let requestBody = {
        id: selectedComplaint.id,
        Status: updatedStatus.status,
      };
      const response = await fetch(`http://localhost:4000/updateComplaintStatus`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        throw new Error('Failed to update complaint status');
      }

      const data = await response.json();

      if (data && data.message) {

        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: data.message,
        });
        setUpdatedStatus({ status: '' });
        fetchComplaints();

       
        
      }
      else{
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Failed to update complaint status',
        });
      }
    } catch (error) {
      console.error('Error updating complaint status:', error.message);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Failed to update complaint status',
      });
    }
  };

  useEffect(() => {
    fetchComplaints();
  }
    , []);

    const filteredComplaints = complaints.filter((complaint) => {
      let match = true;
      if(filterCriteria.Status && complaint.Status !== filterCriteria.Status){
          match = false;
      }
      if(filterCriteria.user && complaint.user !== filterCriteria.user){
          match = false;
      }
      return match;

  });
  const handleFilterIconClick = () => {
    setFilterClicked(!filterClicked);
    setShowFilterMenu(!showFilterMenu);
};
  return (
    <>
      <div className="relative">
                <button className="absolute -top-10 right-0 p-2 bg-primary rounded-md" onClick={handleFilterIconClick}>
                    {
                        filterClicked ? (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
                            </svg>
                        )
                    }
                </button>
                {/* Filter Dropdown Menu */}
                {showFilterMenu && (
                    <div className="absolute -top-1 right-9 bg-white border p-4 rounded shadow w-60">
                        {/* Gender Filter */}
                        <div className='mb-2'>
                            <label className="block ">User</label>
                            <select className="border p-2 rounded w-full" value={filterCriteria.user} onChange={(e) => handleFilterChange('user', e.target.value)}>
                                <option value="">All</option>
                                <option value="driver">Driver</option>
                                <option value="passenger">Passenger</option>
                            </select>
                        </div>
                   
                        <div className='mb-2'>
                            <label className="block">Status</label>
                            <select className="border p-2 rounded w-full" 
                                value={filterCriteria.Status}
                            onChange={(e) => handleFilterChange('Status', e.target.value)}
                            >
                                <option value="">All</option>
                                <option value="Pending">Pending</option>
                                <option value="Resolved">Resolved</option>
                                
                            </select>
                            
                        </div>
                        {/* clear all */}
                        <div>
                            <button
                                onClick={() => {
                                    setFilterCriteria({ 
                                        Status: '',
                                        user:''
                                    });
                                }
                                }
                                className='text-sm mt-2 border border-meta-5 p-2 rounded-full'
                            >
                                Clear All
                            </button>
                            </div>

                    </div>
                )}
            </div>
      <div className=' overflow-x-auto  rounded-md sm:w-full w-[25rem]'>

        <table className='text-sm text-left rtl:text-left w-full'>
          <thead className='text-xs  uppercase  bg-meta-2 text-meta-4'>
            <tr className='  '>
              <th scope="col" className="px-6 py-3">Name </th>
              <th scope="col" className="px-6 py-3">Email</th>
              <th scope="col" className="px-6 py-3">Phone</th>
              <th scope="col" className="px-6 py-3">User</th>
              <th scope="col" className="px-6 py-3">Details</th>
              <th scope="col" className="px-6 py-3">Status</th>

            </tr>
          </thead>
          <tbody className=' justify-between bg-white'>
            {
              filteredComplaints.map((complaint) => (
                <tr key={complaint.id} className=' border-meta-9 border-b '>
                  <td className="px-6 py-4 whitespace-nowrap">{complaint.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{complaint.Email}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{complaint.phone}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{complaint.user}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{complaint.Description}</td>
                  <td className="px-5 py-3 whitespace-nowrap">
                    {(role === 'customer-support' || role === 'super-admin') && (
                      <select
                        className={`p-2 rounded-full ${complaint.Status.toLowerCase() === 'resolved'
                          ? 'bg-primary text-white'
                            : 'bg-warning text-white'
                          } `}
                        onChange={(e) => {
                          const selectedStatus = e.target.value;
                          setSelectedComplaint(complaint);
                          setUpdatedStatus({
                            status: selectedStatus
                          });
                        }}
                        value={complaint.Status.toLowerCase() === 'resolved' ? 'Resolved' : 'Pending'}
                      >
                        <option disabled value="Pending">Pending</option>
                        <option value="Resolved">Resolved</option>
                      </select>
                    )}
                    {(role === 'customer-support' || role === 'super-admin') && (
                      <div>
                        <button className='text-sm mt-2 border border-strokedark p-2 rounded-full'
                          onClick={handleUpdateStatus}
                          >
                            Update Status</button>
                      </div>
                    )}
                  </td>




                </tr>
              ))
            }

          </tbody>
        </table>
      </div>
    </>
  )
}

import React, { useEffect, useState } from 'react'
import { Modal, } from 'flowbite-react';
import Swal from 'sweetalert2';

export default function Drivers() {


    const [imageModal, setImageModal] = useState(false);
    const [reasonModal, setReasonModal] = useState(false);


    const [selectedImage, setSelectedImage] = useState(null);
    const [drivers, setDrivers] = useState([]);
    const [selectedDriver, setSelectedDriver] = useState({
        id: '',
        firstName: '',
        lastName: '',
        Status: ''
    });
    const [updatedStatus, setUpdatedStatus] = useState({
        name: '',
        status: ''
    });
    const [rejectionReason, setRejectionReason] = useState('');
    const role = sessionStorage.getItem('role');
    const [loading, setLoading] = useState(true);
    const [filterCriteria, setFilterCriteria] = useState({
        gender: '',
        age: '',
        Vehicle: '',
        Status: ''
    });
    const [showFilterMenu, setShowFilterMenu] = useState(false);

    const[filterClicked, setFilterClicked] = useState(false);

    //fetch all drivers
    const fetchDrivers = async () => {
        try {
            const response = await fetch('http://localhost:4000/getDrivers');
            if (!response.ok) {
                throw new Error('Failed to fetch drivers');
            }

            const data = await response.json();

            if (data && data.drivers) {
                setDrivers(data.drivers);
            } else {
                setDrivers([]);
            }
        } catch (error) {
            console.error('Error fetching drivers:', error.message);
        }
        finally {
            setLoading(false);
        }
    };

    const handleImageClick = (image) => {
        setSelectedImage(image);
        setImageModal(true);
    }

    const handleUpdateStatus = async () => {
        if(updatedStatus.status === ''){
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Please change the status to update it.',
            });
            return;
        }

        try {
            let requestBody = {
                id: selectedDriver.id,
                Status: updatedStatus.status,
            };

            // Add reasonOfRejection if status is 'Rejected'
            if (updatedStatus.status === 'Rejected') {

                requestBody.reasonOfRejection = rejectionReason;
            }

            const response = await fetch('http://localhost:4000/updateDriverStatus', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestBody),
            });
            if (!response.ok) {
                throw new Error('Failed to update status');
            }
            const data = await response.json();
            if (data && data.message) {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Status updated successfully',
                });
                setRejectionReason('');
                setUpdatedStatus({
                    name: '',
                    status: ''
                });
                setReasonModal(false);
                fetchDrivers();
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Failed to update status',
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Failed to update status',
            });
            console.error('Error updating status:', error.message);
        }
    };


    useEffect(() => {
        fetchDrivers();
    }
        , []);

    const handleFilterChange = (criteria, value) => {
        setFilterCriteria({ ...filterCriteria, [criteria]: value });
    };

    // filter drivers based on filter criteria
    const filteredDrivers = drivers.filter(driver => {
        let match = true;
        if (filterCriteria.gender && driver.gender !== filterCriteria.gender) {
            match = false;
        }
        if (filterCriteria.age && driver.age !== parseInt(filterCriteria.age)) {
            match = false;
        }
        if (filterCriteria.Vehicle && driver.VehicalType !== filterCriteria.Vehicle) {
            match = false;
        }
        if (filterCriteria.Status && driver.Status !== filterCriteria.Status) {
            match = false;
        }
        return match;
    });

    // handle filter icon click
    const handleFilterIconClick = () => {
        setFilterClicked(!filterClicked);
        setShowFilterMenu(!showFilterMenu);
    };
    return (
        <>{/* Filter Icon */}
            <div className="relative">
                <button className="absolute -top-10 right-0 p-2 bg-primary rounded-md" onClick={handleFilterIconClick}>
                    {
                        filterClicked ? (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
                            </svg>
                        )
                    }
                </button>
                {/* Filter Dropdown Menu */}
                {showFilterMenu && (
                    <div className="absolute -top-1 right-9 bg-white border p-4 rounded shadow w-60">
                        {/* Gender Filter */}
                        <div className='mb-2'>
                            <label className="block ">Gender</label>
                            <select className="border p-2 rounded w-full" value={filterCriteria.gender} onChange={(e) => handleFilterChange('gender', e.target.value)}>
                                <option value="">All</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        {/* Age Filter */}
                        {/* <div>
                            <label className="block mb-2">Age</label>
                            <input type="text" className="border p-2 rounded" value={filterCriteria.age} onChange={(e) => handleFilterChange('age', e.target.value)} />
                        </div> */}
                        {/* Vehicle Filter */}
                        <div className='mb-2'>
                            <label className="block ">Vehicle</label>
                            <select className="border p-2 rounded w-full" value={filterCriteria.Vehicle} onChange={(e) => handleFilterChange('Vehicle', e.target.value)}>
                                <option value="">All</option>
                                <option value="Car">Car</option>
                                <option value="Bike">Bike</option>
                            </select>
                        </div>
                        {/* Status filter */}
                        <div className='mb-2'>
                            <label className="block">Status</label>
                            <select className="border p-2 rounded w-full" onChange={(e) => handleFilterChange('Status', e.target.value)}
                            >
                                <option value="">All</option>
                                <option value="Approved">Approved</option>
                                <option value="Rejected">Rejected</option>
                                <option value="Pending">Pending</option>
                            </select>
                            
                        </div>
                        {/* clear all */}
                        <div>
                            <button
                                onClick={() => {
                                    setFilterCriteria({ 
                                        Status: '',
                                        Vehicle: '',
                                        age: '',
                                        gender: ''
                                    });
                                }
                                }
                                className='text-sm mt-2 border border-meta-5 p-2 rounded-full'
                            >
                                Clear All
                            </button>
                            </div>

                    </div>
                )}
            </div>
            <div className=' overflow-x-auto  rounded-md sm:w-full w-[25rem] '>
                {
                    loading ? (
                        <div className="flex justify-center items-center">
                            <div className="mt-4 animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                        </div>
                    ) : (
                    <>
                    {
                        filteredDrivers.length>0 ?(
                            <table className='text-sm text-left rtl:text-left'>
                            <thead className='text-xs uppercase bg-meta-2 text-meta-4'>
                                <tr>
                                    <th scope="col" className="px-6 py-3">Name</th>
                                    <th scope="col" className="px-6 py-3">Email</th>
                                    <th scope="col" className="px-6 py-3">Phone</th>
                                    <th scope="col" className="px-6 py-3">Age</th>
                                    <th scope="col" className="px-6 py-3">Gender</th>
                                    <th scope="col" className="px-6 py-3">Driver License</th>
                                    <th scope="col" className="px-6 py-3">Car Picture</th>
                                    <th scope="col" className="px-6 py-3">Vehicle</th>
                                    <th scope="col" className="px-6 py-3">CNIC</th>
                                    <th scope="col" className="px-6 py-3">Photo</th>
                                    <th scope="col" className="px-6 py-3">Status</th>
                                </tr>
                            </thead>
                            <tbody className='justify-between bg-white'>
                                {filteredDrivers.map((driver, index) => (
                                    <tr key={index} className='border-meta-9 border-b'>
                                        <td className="px-6 py-4 text-left capitalize">{driver.display_name}</td>
                                        <td className="px-6 py-4 text-left">{driver.email}</td>
                                        <td className="px-6 py-4 text-left">{driver.phone_number}</td>
                                        <td className="px-6 py-4 text-left">{driver.age}</td>
                                        <td className="px-6 py-4 text-left">{driver.gender}</td>
                                        <td className="px-6 py-4 text-left">
                                            <button
                                                disabled={role === 'super-admin' || role === 'super-admin' ? false : true}
                                                onClick={() => { handleImageClick(driver.license) }}
                                            >
                                                <img className='w-20 h-20' src={driver.license} alt="" />
                                            </button>
                                        </td>
                                        <td className="px-6 py-4 text-left">
                                            <button
                                                disabled={role === 'super-admin' || role === 'super-admin' ? false : true}
                                                onClick={() => { handleImageClick(driver.carlicense) }}
                                            >
                                                <img className='w-20 h-20' src={driver.carlicense} alt="" />
                                            </button>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">{driver.VehicalType}</td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <button
                                                disabled={role === 'driver-management' || role === 'super-admin' ? false : true}
                                                onClick={() => { handleImageClick(driver.CNIC_url) }}
                                            >
                                                <img className='w-20 h-20' src={driver.CNIC_url} alt="" />
                                            </button>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <button
                                                disabled={role === 'driver-management' || role === 'super-admin' ? false : true}
                                                onClick={() => { handleImageClick(driver.photo_url) }}
                                            >
                                                <img className='w-20 h-20' src={driver.photo_url} alt="" />
                                            </button>
                                        </td>
                                        <td className="px-5 py-3 whitespace-nowrap">
                                            {(role === 'driver-management' || role === 'super-admin') && (
                                                <select
                                                    className={`p-2 rounded-full ${driver.Status === 'Approved' || driver.Status === 'approved' || driver.Status === 'APPROVED'
                                                        ? 'bg-primary text-white'
                                                        : driver.Status === 'Rejected'
                                                            ? 'bg-meta-1 text-white'
                                                            : 'bg-warning text-white'
                                                        } `}
                                                    onChange={(e) => {
                                                        const selectedStatus = e.target.value;
                                                        if (selectedStatus === 'Rejected') {
                                                            setReasonModal(true);
                                                        } else {
                                                            setReasonModal(false);
                                                        }
                                                        setSelectedDriver(driver);
                                                        setUpdatedStatus({
                                                            name: driver.display_name,
                                                            status: selectedStatus
                                                        });
                                                    }}
                                                    value={driver.Status}
                                                >
                                                    <option disabled value="Pending">Pending</option>
                                                    <option value="Approved">Approved</option>
                                                    <option value="Rejected">Rejected</option>
                                                </select>
                                            )}
                                            {(role === 'driver-management' || role === 'super-admin') && (
                                                <div>
                                                    <button className='text-sm mt-2 border border-strokedark p-2 rounded-full'
                                                        onClick={handleUpdateStatus}>Update Status</button>
                                                </div>
                                            )}
                                        </td>
                                    </tr>
                                )
                                )}
                            </tbody>
                        </table>
                        ):(
                            <div className='flex justify-center items-center h-96'>
                            <h1 className='text-2xl text-black'>No drivers found</h1>
                        </div>
                        )
                    }
                        

                    </>
                    )


                }


            </div>

            {/*  image modal */}

            <Modal show={imageModal} onClose={() => setImageModal(false)} popup className=' pt-20 bg-black bg-opacity-50'>
                <Modal.Header />
                <Modal.Body>
                    <div className="">
                        <img
                            className=' '
                            src={selectedImage} alt="" />
                    </div>
                </Modal.Body>
            </Modal>

            {/*  rejection reason modal */}
            <Modal show={reasonModal} onClose={() => setReasonModal(false)} popup className=' pt-20 bg-black bg-opacity-50'>
                <Modal.Header />
                <Modal.Body>
                    <div className="flex flex-col items-center">
                        <input
                            type="text"
                            placeholder="Enter reason of rejection"
                            value={rejectionReason}
                            onChange={(e) => setRejectionReason(e.target.value)}
                            className='border border-strokedark p-2 rounded-full w-72'
                        />
                        <button
                            onClick={handleUpdateStatus}
                            className='text-sm mt-2   border border-strokedark p-2 rounded-full'
                        >
                            Update Status
                        </button>
                    </div>
                </Modal.Body>
            </Modal>




        </>
    )
}

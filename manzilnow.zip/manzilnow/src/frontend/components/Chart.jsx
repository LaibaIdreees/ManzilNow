
import { Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
export default function Chart() {


    const data = {
        labels: ["Red", "Blue", "Yellow"],
        datasets: [
        {
            label: "# of Votes",
            data: [12, 19, 3],
            backgroundColor: ["black", "blue", "white"],
            borderColor: ["black", "blue", "white"],
            borderWidth: 1,
        },
        ],
    };
    
    const options = {
        plugins: {
        legend: {
            position: "bottom",
        },
        },
    };
    ChartJS.register(ArcElement, Tooltip, Legend);
    return (
        <div className="w-80">
        <Doughnut data={data} options={options} />
        </div>
    );
}
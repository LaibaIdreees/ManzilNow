// src/components/Admins.js
import React, { useState, useEffect } from 'react';
import { Button, Label, Modal, TextInput } from 'flowbite-react';
import Swal from 'sweetalert2';
import { FaPlus } from 'react-icons/fa';

const Admins = () => {

  const [loading, setLoading] = useState(true);
  const [openAddAdminModal, setOpenAddAdminModal] = useState(false);

  const [newAdminRole, setNewAdminRole] = useState('');
  const [adminsData, setAdminsData] = useState([]);
  const [newName, setNewName] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  var [newAdminPassword, setNewAdminPassword] = useState('');

  const role = sessionStorage.getItem('role');
  const [updatedRole, setUpdatedRole] = useState({
    name: '',
    role: '',
    id: '',
  });

  var currentUserId = sessionStorage.getItem('id');

  function onCloseModal() {
    setOpenAddAdminModal(false);
    setNewAdminEmail('');
    setNewName('');
    setNewAdminPassword('');


  }
  //fetching admins
  const fetchAdmins = async () => {
    try {
      const response = await fetch('http://localhost:4000/getAllAdmins');
      if (!response.ok) {
        throw new Error('Failed to fetch admins');
      }

      const data = await response.json();
      if (data && data.admins) {
        setAdminsData(data.admins);

      } else {
        setAdminsData([]);
      }
    } catch (error) {
      console.error('Error fetching admins:', error.message);
    }
    finally {
      setLoading(false)
    }
  };
  //send email to new admin
  const sendEmail = async () => {

    try {
      const response = await fetch('http://localhost:4000/sendEmail', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: newAdminEmail, password: newAdminPassword }),
      });
      const data = await response.json();
      if (data.status === 'success') {
        setNewAdminEmail('');
        setNewName('');
        setNewAdminPassword('');

        Swal.fire({
          title: 'Admin added successfully',
          text: 'Email sent successfully',
          icon: 'success',
        });
      }

    }
    catch (error) {
      console.log(error);
    }
  };
  //generating random password
  const generatePassword = () => {
    var length = 8,
      charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
      retVal = '';
    for (var i = 0, n = charset.length; i < length; ++i) {
      retVal += charset.charAt(Math.floor(Math.random() * n));
    }

    return retVal;

  };


  // add new admin
  const handleAddAdmin = async () => {

    newAdminPassword = generatePassword();


    if (newName === '' || newAdminEmail === '' || newAdminRole === '' || newAdminPassword === '') {
      Swal.fire({
        title: 'Empty Fields',
        text: 'Please fill all the fields',
        icon: 'error',
      });
      return;
    }
    if (newAdminEmail.indexOf('@') === -1 || newAdminEmail.indexOf('.') === -1) {
      Swal.fire({
        title: 'Invalid Email',
        text: 'Please enter a valid email',
        icon: 'error',
      });
      return;
    }
    const namePattern = /^[a-zA-Z]+$/;
    if (!namePattern.test(newName)) {
      Swal.fire({
        title: 'Invalid Name',
        text: 'Name should contain only letters',
        icon: 'error',
      });
      return;
    }

    // fields should not contain code
    const codePattern = /<|> /;
    if (codePattern.test(newName) || codePattern.test(newAdminEmail)) {
      Swal.fire({
        title: 'Invalid characters',
        text: 'Fields should not contain < or >',
        icon: 'error',
      });
      return;
    }
    
    

    try {
      const response = await fetch('http://localhost:4000/addAdmin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: newName, email: newAdminEmail, password: newAdminPassword, role: newAdminRole }),
      });
      if (response.ok) {
        sendEmail();
        await fetchAdmins();
        onCloseModal();

      }
      else if (response.status === 400) {
        Swal.fire({
          title: 'Admin already exists',
          icon: 'error',
        });
      }
    }
    catch (error) {
      console.log(error);
    }
  };
  //update admin info
  const handleUpdateAdminInfo = async () => {
    if (updatedRole.role === '') {
      Swal.fire({
        title: 'Unchanged filed',
        text: 'Please change admin role',
        icon: 'error',
      });
      return;
    }

    try {
      const response = await fetch('http://localhost:4000/updateAdminInfo', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: updatedRole.id,
          role: updatedRole.role,
          name: '',
          email: '',
        }),
      });
      if (response.ok) {
        Swal.fire({
          title: 'Admin info updated successfully',
          icon: 'success',
        });

        await fetchAdmins();
      }

    }
    catch (error) {
      console.log(error);
    }
  };
  //delete admin
  const handleDeleteButtonClick = async (admin) => {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to delete this admin",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#4A5899',
      cancelButtonColor: 'gray',
      confirmButtonText: 'Yes, delete it!'
    }).then(async (result) => {
      if (result.isConfirmed) {

        try {
          const response = await fetch('http://localhost:4000/deleteAdmin', {
            method: 'DELETE',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: admin.id }),
          });
          if (response.ok) {
            await fetchAdmins();
            Swal.fire({
              title: 'Admin deleted successfully',
              icon: 'success',
            });
          }
        }
        catch (error) {
          console.log(error);
        }
      }
    }
    )

  };


  useEffect(() => {
    fetchAdmins();
  }, []);


  return (
    <>
      <div className=' flex justify-end -mt-10 mb-5'>
        <button className=' rounded-md p-3 focus:ring-0 bg-primary' onClick={() => setOpenAddAdminModal(true)}>
          <FaPlus className='text-white' />
        </button>
      </div>

      {
        loading ? (
          <div className="flex justify-center items-center">
            <div className="mt-4 animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className='   rounded-md sm:w-full w-[25rem]  '>

            <table className='animated fadeInUp text-sm text-left rtl:text-left w-full '>
              <thead className='text-xs  uppercase  bg-meta-2 text-meta-4'>
                <tr className=' '>
                  <th scope="col" className="px-6 py-3">Name</th>
                  <th scope="col" className="px-6 py-3">Email</th>
                  <th scope="col" className="px-6 py-3">Role</th>
                  <th scope="col" className="px-6 py-3">
                    <span></span>
                  </th>
                  <th scope="col" className="px-6 py-3">
                    <span></span>
                  </th>

                </tr>
              </thead>

              <tbody className=' justify-between bg-white'>
                {adminsData.map((admin) => (
                  <tr className=' border-b  border-meta-9' key={admin.id}>
                    <td className='px-6 py-4'>{admin.name}</td>
                    <td className='px-6 py-4'>{admin.email}</td>
                    <td className='px-6 py-4'>
                      {(role === 'super-admin') && (
                        <select
                          className={`p-2 rounded-full
          
                    `}
                          disabled={role === 'super-admin' && admin.role === 'super-admin' && admin.id === currentUserId}
                          onChange={(e) => {
                            setUpdatedRole({
                              ...updatedRole,
                              role: e.target.value,
                              id: admin.id,

                            });
                          }}
                          value={admin.role}
                        >
                          <option value="super-admin">Super Admin</option>
                          <option value="driver-management">Driver Management</option>
                          <option value="customer-support">Customer Support</option>
                          <option value="fair-management">Fair Management</option>
                        </select>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        disabled={role === 'super-admin' && admin.role === 'super-admin'}
                        onClick={handleUpdateAdminInfo} className="font-medium text-blue-600  hover:underline">Update Role</button>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        disabled={(role === 'super-admin' && admin.role === 'super-admin' && admin.id === currentUserId)}
                        onClick={() => handleDeleteButtonClick(admin)}
                        className="font-medium text-red-600 hover:underline"
                      >
                        Delete
                      </button>
                    </td>

                  </tr>
                ))}


              </tbody>
            </table>

          </div>
        )
      }


      {/* {add admin modal} */}
      <Modal show={openAddAdminModal} size="md" onClose={onCloseModal} popup className='pt-20'>
        <Modal.Header />
        <Modal.Body>
          <div className="space-y-6"
          >
            <h3 className="text-xl font-medium">Add Admin</h3>
            <div>
              <div className="mb-2 block">
                <Label htmlFor="name" value="Name" />
              </div>
              <TextInput
                className=' bg-transparent '
                id="name"
                placeholder=""
                onChange={(e) => setNewName(e.target.value)
                }
                required
              />
            </div>
            <div>
              <div className="mb-2 block">
                <Label htmlFor="email" value="Email" />
              </div>
              <TextInput
                className='  '
                id="email"
                placeholder=""
                value={newAdminEmail}
                onChange={(event) => setNewAdminEmail(event.target.value)}

                required
              />
            </div>
            <div>
              <div className="mb-2 block">
                <Label htmlFor="Role" value="Role" />
              </div>
              <select className=' rounded-md w-full p-2 border border-meta-9  focus:outline-none focus:ring-2 focus:ring-meta-4 focus:border-transparent'
                onChange={(e) => {
                  setNewAdminRole(e.target.value);
                }}
              >
                <option
                  value="" selected disabled>Select a role</option>
                <option value="super-admin" className=' text-black'>Super Admin</option>
                <option value="customer-support" className=' text-black'>Customer Suport</option>
                <option value="fair-management" className=' text-black'>Fair Management</option>
                <option value="driver-management" className=' text-black'>Driver Management</option>
              </select>
            </div>
            <Button className='w-full bg-primary' onClick={handleAddAdmin}>Add Admin</Button>
          </div>
        </Modal.Body>
      </Modal>


    </>

  );
};

export default Admins;

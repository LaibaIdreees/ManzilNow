import React, { useState, useEffect } from 'react';
import ReactApexChart from 'react-apexcharts';

const ChartThree = () => {
  const [passengers, setPassengers] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchPassengers = async () => {
    try {
      const response = await fetch('http://localhost:4000/getPassengers');
      if (!response.ok) {
        throw new Error('Failed to fetch passengers');
      }

      const data = await response.json();

      if (data && data.passengers) {
        setPassengers(data.passengers);
      } else {
        setPassengers([]);
      }
    } catch (error) {
      console.error('Error fetching passengers:', error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPassengers();
  }, []);

  const calculateChartData = () => {

    const genderCounts = passengers.reduce((acc, passenger) => {
      acc[passenger.gender] = (acc[passenger.gender] || 0) + 1;
      return acc;
    }, {});

    return {
      series: Object.values(genderCounts),
      options: {
        chart: {
          type: 'donut',
        },
        colors: ['#3C50E0', '#80CAEE'],
        legend: {
          show: true,
          position: 'bottom',
          fontSize: '16px',
          fontWeight: 400,
        },
        labels:['Male','Female'],
        plotOptions: {
          pie: {
            donut: {
              labels: {
                show: true,
                name: {
                  show: true,
                  fontSize: '20px',
                  fontFamily: 'Satoshi, sans-serif',
                  fontWeight: 400,
                  color: undefined,
                  offsetY: -10,
                },
                value: {
                  show: true,
                  fontSize: '20px',
                  fontFamily: 'Satoshi, sans-serif',
                  fontWeight: 400,
                  color: undefined,
                  offsetY: 16,
                  formatter: function (val) {
                    return val;
                  },
                },
                total: {
                  show: true,
                  label: 'Total',
                  
                  formatter: function (w) {
                    return w.globals.seriesTotals.reduce((a, b) => {
                      return a + b;
                    }, 0);
                  },
                },
              },
              size: '60%',
              background: 'transparent',
            },
          },
        },
        dataLabels:{
          enabled: false,

        },
        responsive: [{
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            }
          }
        }]
      },
    };
};


  const { series, options } = calculateChartData();

  return (
    <div className="col-span-12 rounded-sm border border-stroke bg-white px-5 pt-7.5 pb-5 shadow-default sm:px-7.5 xl:col-span-5">
      {/* Your JSX for chart component */}
      <h2 className="text-2xl font-semibold text-title">Passenger
        <span className="text-primary"> Statistics</span>
      </h2>
      <p className="text-sm">Passenger statistics based on 
        <span className="text-primary"> Gender</span>
      </p>

      {loading ? (
        <div className="flex justify-center items-center">
          <div className="mt-4 animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : (
        // Show chart when data is loaded
        <div id="chartThree" className="mx-auto flex justify-center">
          <ReactApexChart options={options} series={series} type="donut" width={390} height={390}
           />
        </div>
      )}
    </div>
  );
};

export default ChartThree;

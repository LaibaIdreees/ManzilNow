import React, { useState, useEffect } from 'react'
import { Card } from 'flowbite-react';
import { VscCheck, VscClose } from "react-icons/vsc";
import Swal from 'sweetalert2';
import CountUp from 'react-countup';
export default function Payments() {
    const [loading, setLoading] = useState(true);
    const [completedRide, setCompletedRide] = useState([]);
    const [totalFare, setTotalFare] = useState(0);


    const fetchCompletedRide = async () => {
        try {
            const response = await fetch('http://localhost:4000/getCompletedRide');
            if (!response.ok) {
                throw new Error('Failed to fetch completed ride');
            }

            const data = await response.json();

            if (data && data.completedRide) {
                setCompletedRide(data.completedRide);
                console.log(data.completedRide);
            } else {
                setCompletedRide([]);
            }
        } catch (error) {
            console.error('Error fetching completed ride:', error.message);
        }
        finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchCompletedRide();
    }
        , []);

    useEffect(() => {
        // Calculate total fare
        let total = 0;
        completedRide.forEach((ride) => {
            total += ride.fare;
        });
        setTotalFare(total);
    }, [completedRide]);
    return (
        <>
            <div className=' rounded-md sm:w-full w-[25rem]'>

                {

                    loading ? (
                        <div className="flex justify-center items-center">
                            <div className="mt-4 animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                        </div>
                    ) : (
                        <table className='animated fadeInUp text-sm text-left rtl:text-left w-full'>
                            <thead className='text-xs  uppercase  bg-meta-2 text-meta-4'>
                                <tr className=' '>
                                    <th scope="col" className="px-6 py-3">Name</th>
                                    <th scope="col" className="px-6 py-3">Distance</th>
                                    <th scope="col" className="px-6 py-3">Paymnet Method</th>
                                    <th scope="col" className="px-6 py-3">Picup Location</th>
                                    <th scope="col" className="px-6 py-3">Destination</th>
                                    <th scope="col" className="px-6 py-3">Paymnet</th>


                                </tr>
                            </thead>
                            <tbody className=' justify-between bg-white'>
                                {
                                    completedRide.map((ride) => (
                                        <tr key={ride.id} className='border-meta-9 border-b '>
                                            <td className="px-6 py-4 text-left ">{ride.display_name}</td>
                                            <td className="px-6 py-4 text-left ">
                                                {`${ride.distance}` + ' Km'}
                                            </td>
                                            <td className="px-6 py-4 text-left ">{ride.paymentMethod}</td>
                                            <td className="px-6 py-4 text-left ">{ride.pickup_add}</td>
                                            <td className="px-6 py-4 text-left ">{ride.destination_add}</td>
                                            <td className="px-6 py-4 text-left text-lg ">

                                                {`${ride.fare}` + ' Rs'}


                                            </td>

                                        </tr>


                                    ))
                                }


                            </tbody>
                        </table>


                    )
                }

                <div className="flex justify-end mt-4 animated fadeInUp  ">
                    <Card className="flex    rounded-sm border border-stroke bg-white py-6 px-7.5 shadow-default h-full">
                        <div className="flex justify-between items-center">
                            <span>Total Fare:&nbsp;</span>{' '}
                            <span className=' text-success text-xl font-semibold'>
                                <CountUp end={totalFare} duration={2} /> Rs
                            </span>
                        </div>
                    </Card>
                </div>
            </div>

        </>
    )
}

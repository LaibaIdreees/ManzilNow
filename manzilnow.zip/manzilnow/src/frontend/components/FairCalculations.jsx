import React, { useState, useEffect } from 'react';
import { Card } from 'flowbite-react';
import { IoCarSport } from "react-icons/io5";
import { RiMotorbikeFill } from "react-icons/ri";
import { MdElectricRickshaw } from "react-icons/md";
import CountUp from 'react-countup';
import Swal from 'sweetalert2';
import { FaGasPump } from 'react-icons/fa6';
import { Button, Label, Modal, TextInput } from 'flowbite-react';

export default function FairCalculations() {

  const[showBikeModal, setShowBikeModal] = useState(false);
  const[showCarModal, setShowCarModal] = useState(false);
  const[showRickshawModal, setShowRickshawModal] = useState(false);
  const[showFuelModal, setShowFuelModal] = useState(false);

  const [carFuelConsumption, setCarfuelConsumption] = useState(0);
  const [bikeFuelConsumption, setBikefuelConsumption] = useState(0);
  const [rickshawFuelConsumption, setRickshawfuelConsumption] = useState(0);

  const [fuelPrice, setFuelPrice] = useState(0);

  const [carBaseFare, setCarBaseFare] = useState(0);
  const [rickshawBaseFare, setRickshawBaseFare] = useState(0);
  const [bikeBaseFare, setBikeBaseFare] = useState(0);
  const [id, setId] = useState(0);

  const updateFare = async () => {


    Swal.fire({
      title: 'Are you sure?',
      text: `You want to update  Fare`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: `Yes, Update  Fare!`
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          const response = await fetch(`http://localhost:4000/updateFare`, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              id,
              bikeBaseFare,
              bikeFuelConsumption,
              carBaseFare,
              carFuelConsumption,
              rickshawBaseFare,
              rickshawFuelConsumption,
              fuelPrice
              
            })
          });

          if (response.ok) {
            setShowBikeModal(false);
            setShowCarModal(false);
            setShowRickshawModal(false);
            setShowFuelModal(false);
            Swal.fire(
              'Updated!',
              ` Fare Updated Successfully`,
              'success'
            )
          }
          else {
            Swal.fire(
              'Failed!',
              'Something went wrong',
              'error'
            )
          }
        }
        catch (error) {
          console.log(error);
        }
      }
    });
  };

  const getFare = async () => {
    try {
      const response = await fetch('http://localhost:4000/getFare');
      if (response.ok) {
        const data = await response.json();
        if (data.fares && data.fares.length > 0) {
          const fareData = data.fares[0]; // Assuming you only have one entry
          setId(fareData.id)
          setCarfuelConsumption(fareData.carFuelConsumption);
          setCarBaseFare(fareData.carBaseFare);
          setRickshawfuelConsumption(fareData.rickshawFuelConsumption);
          setRickshawBaseFare(fareData.rickshawBaseFare);
          setBikefuelConsumption(fareData.bikeFuelConsumption);
          setBikeBaseFare(fareData.bikeBaseFare);
          setFuelPrice(fareData.fuelPrice);
        } else {
          console.error('No fare data found');
        }
      } else {
        console.error('Failed to fetch data');
      }
    } catch (error) {
      console.log(error);
    }
  };
  

  useEffect(() => {
    getFare();
  }
  , []);

  return (
    <>


      {/*  ## */}
      <div className='animated fadeInUp grid grid-cols-3 gap-4'>
        {/* Bike card */}
        <div className='bg-black'>
          <Card className=" rounded-sm border border-stroke bg-white py-6 px-2 shadow-default">
            <div className='flex space-x-8 w-full items-center'>
              <div onClick={() => setShowBikeModal(true)}
               className='flex h-18 w-20 items-center justify-center rounded-md bg-meta-2 cursor-pointer hover:bg-meta-9 duration-300 transition-all '>
                <RiMotorbikeFill className='text-4xl text-primary' />

              </div>
              <h1 className=' text-title-xl'>Bike</h1>
            </div>
            <hr className=' text-meta-9' />
            <div className='flex justify-between w-full'>
              <div className='flex flex-col'>

                <div className=' flex items-center space-x-2'>
                  <p className=' text-title-lg font-semibold text-black'>
                    <CountUp end={bikeFuelConsumption} duration={1} />
                  </p>
                  <span className='text-sm text-bodydark2 italic '>Ltr / 100 km</span>
                </div>
                <p className='font-semibold'>Fuel Consumption</p>

              </div>
              <div className='flex flex-col'>
                <div className='flex items-center space-x-2'>
                  <p className=' text-title-lg font-semibold text-black'>
                    <CountUp end={bikeBaseFare} duration={1} />
                  </p>
                  <span className='text-sm text-bodydark2 italic '>Rs</span>
                </div>
                <p className=' font-semibold'>Base Fare</p>

              </div>
            </div>
          </Card>

        </div>
        {/* Rickshaw card */}
        <div className='bg-black'>
          <Card className=" rounded-sm border border-stroke bg-white py-6 px-2 shadow-default">
            <div className='flex space-x-8 w-full items-center'>
              <div 
              onClick={() => setShowRickshawModal(true)}
              className='flex h-18 w-20 items-center justify-center rounded-md bg-meta-2 cursor-pointer hover:bg-meta-9 duration-300 transition-all '>
                <MdElectricRickshaw className='text-4xl text-primary' />

              </div>
              <h1 className=' text-title-xl'>Rickshaw</h1>
            </div>
            <hr className=' text-meta-9' />
            <div className='flex justify-between w-full'>
              <div className='flex flex-col'>

                <div className=' flex items-center space-x-2'>
                  <p className=' text-title-lg font-semibold text-black'>
                    <CountUp end={rickshawFuelConsumption} duration={1} />
                  </p>
                  <span className='text-sm text-bodydark2 italic '>Ltr / 100 km</span>
                </div>
                <p className='font-semibold'>Fuel Consumption</p>
              </div>
              <div className='flex flex-col'>
                <div className='flex items-center space-x-2'>
                  <p className=' text-title-lg font-semibold text-black'>
                    <CountUp end={rickshawBaseFare} duration={1} />
                  </p>
                  <span className='text-sm text-bodydark2 italic '>Rs</span>
                </div>

                <p className=' font-semibold'>Base Fare</p>

              </div>
            </div>
          </Card>
        </div>
        {/* Car card */}
        <div className=''>
          <Card className=" rounded-sm border border-stroke bg-white py-6 px-2 shadow-default">
            <div className='flex space-x-8 w-full items-center'>
              <div 
              onClick={() => setShowCarModal(true)}
              className='flex h-18 w-20 items-center justify-center rounded-md bg-meta-2 cursor-pointer hover:bg-meta-9 duration-300 transition-all '>
                <IoCarSport className='text-4xl text-primary' />
              </div>
              <h1 className=' text-title-xl '>Car</h1>
            </div>
            <hr className=' text-meta-9' />
            <div className='flex justify-between w-full'>
              <div className='flex flex-col'>

                <div className=' flex items-center space-x-2'>
                  <p className=' text-title-lg font-semibold text-black'>
                    <CountUp end={carFuelConsumption} duration={2} />
                  </p>
                  <span className='text-sm text-bodydark2 italic '>Ltr / 100 km</span>
                </div>
                <p className='font-semibold'>Fuel Consumption</p>

              </div>
              <div className='flex flex-col'>
                <div className='flex items-center space-x-2'>
                  <p className=' text-title-lg font-semibold text-black'>
                    <CountUp end={carBaseFare} duration={2} />
                  </p>
                  <span className='text-sm italic '>Rs</span>
                </div>
                <p className=' font-semibold'>Base Fare</p>

              </div>
            </div>
          </Card>
        </div>
      </div>
      <div className='animated fadeInUp mt-6 flex items-center justify-center '>
        <div className='flex items-center  w-1/2 rounded-sm border border-stroke bg-white py-6 px-2 shadow-default'>
          <div className='flex space-x-8 w-full items-center'>
            <div 
            onClick={() => {setShowFuelModal(true)}}
            className='flex h-18 w-20 items-center justify-center rounded-md bg-meta-2 cursor-pointer hover:bg-meta-9 duration-300 transition-all '>
              <FaGasPump
               className='text-4xl text-primary' />
            </div>
            <h1 className=' text-title-xl '>Fuel Price</h1>
          </div>
          <div className='flex  space-x-2 items-center mr-8'>
            <p className='text-title-xl font-semibold text-black'>
              <CountUp end={fuelPrice} duration={2} />
            </p>
            <p className=' italic'>Rs&nbsp;/&nbsp;Ltr</p>
          </div>
        </div>
      </div>



      {/* Bike Modal */}
      <Modal
        show={showBikeModal}
        size="sm"
        popup
        onClose={() => setShowBikeModal(false)}
        className="pt-20"
      >
        <Modal.Header ><h1 className="text-2xl text-bodydark2 font-medium px-4 py-2">Bike</h1>
        </Modal.Header>
        <Modal.Body>
        <div className="">
          
          <div className="flex items-center justify-between">
            <Label>Base Fare</Label>
            <TextInput
              type="number"
              className='w-26 p-2'
              value={bikeBaseFare}
              onChange={(e) => setBikeBaseFare(e.target.value)}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label>Fuel Consumption</Label>
            <TextInput
              type="number"
              className='w-26 p-2'
              value={bikeFuelConsumption}
              onChange={(e) => setBikefuelConsumption(e.target.value)}
            />
          </div>

        </div>
        <Button className='mt-10 w-full bg-primary' onClick={() => updateFare()} > Update </Button>
        </Modal.Body>
      </Modal>
        
        {/* Car Modal */}
        <Modal
          show={showCarModal}
          size="sm"
          popup
          onClose={() => setShowCarModal(false)}
          className="pt-20"
        >
          <Modal.Header ><h1 className="text-2xl text-bodydark2 font-medium px-4 py-2">Car</h1>
          </Modal.Header>
          <Modal.Body>
            <div className="">
              <div className="flex items-center justify-between">
                <Label>Base Fare</Label>
                <TextInput
                  type="number"
                  className='w-26 p-2'
                  value={carBaseFare}
                  onChange={(e) => setCarBaseFare(e.target.value)}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label>Fuel Consumption</Label>
                <TextInput
                  type="number"
                  className='w-26 p-2'
                  value={carFuelConsumption}
                  onChange={(e) => setCarfuelConsumption(e.target.value)}
                />
              </div>
              <Button
                onClick={() => updateFare()}
                className="mt-10 w-full bg-primary"
              >
                Update
              </Button>
            </div>
          </Modal.Body>
        </Modal>
        {/* Rickshaw Modal */}
        <Modal
          show={showRickshawModal}
          size="sm"
          popup
          onClose={() => setShowRickshawModal(false)}
          className="pt-20"
        >
          <Modal.Header ><h1 className="text-2xl text-bodydark2 font-medium px-4 py-2">Rickshaw</h1>
          </Modal.Header>
          <Modal.Body>
            <div className="">
              <div className="flex items-center justify-between">
                <Label>Base Fare</Label>
                <TextInput
                  type="number"
                  className='w-26 p-2'
                  value={rickshawBaseFare}
                  onChange={(e) => setRickshawBaseFare(e.target.value)}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label>Fuel Consumption</Label>
                <TextInput
                  type="number"
                  className='w-26 p-2'
                  value={rickshawFuelConsumption}
                  onChange={(e) => setRickshawfuelConsumption(e.target.value)}
                />
              </div>
              <Button
                onClick={() => updateFare()}
                className="mt-10 w-full bg-primary"
              >
                Update
              </Button>
            </div>
          </Modal.Body>
        </Modal>
        {/* Fuel Modal */}
        <Modal
          show={showFuelModal}
          size="sm"
          popup
          onClose={() => setShowFuelModal(false)}
          className="pt-20"
        >
          <Modal.Header ><h1 className="text-2xl text-bodydark2 font-medium px-4 py-2">Fuel Price</h1>
          </Modal.Header>
          <Modal.Body>
            <div className="">
              <div className="flex items-center justify-between">
                <Label>Price per Liter</Label>
                <TextInput
                  type="number"
                  className='w-26 p-2'
                  value={fuelPrice}
                  onChange={(e) => setFuelPrice(e.target.value)}
                />
              </div>
              <Button
                onClick={() => updateFare()}
                className="mt-10 w-full bg-primary"
              >
                Update
              </Button>
            </div>
          </Modal.Body>
        </Modal>
    </>
  );
}

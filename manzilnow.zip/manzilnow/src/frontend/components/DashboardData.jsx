import React, { useState, useEffect } from 'react'
import { Card } from 'flowbite-react';
import Chart from './Chart';
import Drivers from './DashboardCards/Drivers';
import ChartOne from './ChartOne';
import PieChart from './ChartThree';
import Admins from './DashboardCards/Admins';
import Passengers from './DashboardCards/Passengers';
import Complaints from './DashboardCards/Complaints';
import PendingDriverApproval from './DashboardCards/PendingDriverApproval';
import ComplaintsToBeResolved from './DashboardCards/ComplaintsToBeResolved';
import Rides from './DashboardCards/Rides';


export default function DashboardData() {

    return (
        <>
            <div className=" grid grid-cols-1 gap-4 md:grid-cols-2 md:gap-6 xl:grid-cols-4 2xl:gap-7.5">
                <div className='animated fadeInUp '>  <Drivers /></div>
                <div className='animated2 fadeInUp '> <Admins /></div>
                <div className='animated3 fadeInUp '> <Passengers /></div>
                <div className='animated3 fadeInUp '> <Rides /></div>

                {/* <div className='animated4 fadeInUp '> <Complaints /></div> */}
                

            </div>
            <div className='animated2  fadeInUp mt-4  grid grid-cols-2 md:mt-6 gap-4 '>
                <div className=' flex flex-col space-y-7'>
                    <PendingDriverApproval />
                    <ComplaintsToBeResolved />
                </div>
                <div><PieChart /></div>
                {/* <div><ChartOne /></div> */}
            </div>

        </>
    )
}

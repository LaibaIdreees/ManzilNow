
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import logo from '../../images/logo.png';

const Login = () => {

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const token = sessionStorage.getItem('token');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!email || !password) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Please fill all the fields!',
      });
      return;
    }

    if (email.length > 100 || password.length > 100) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Email or password is too long!',
      });
      return;
    }

    // Client-side validation to prevent XSS attacks
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Invalid email address!',
      });
      return;
    }

    const suspiciousChars = /<|>/; 
    if (suspiciousChars.test(email) || suspiciousChars.test(password)) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Invalid characters detected!',
      });
      return;
    }
    //password should contain uppercase and lowercase letters
    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])/;
    if (!passwordPattern.test(password)) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Password should contain uppercase and lowercase letters!',
      });
      return;
    }

    try {
      const response = await fetch('http://localhost:4000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          password,
        }),
      });
      const data = await response.json();
      if (data.error) {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: data.error,
        });
      } else {
        sessionStorage.setItem('role', data.admin.role);
        sessionStorage.setItem('name', data.admin.name);
        sessionStorage.setItem('id', data.id);
        sessionStorage.setItem('email', data.admin.email);
        sessionStorage.setItem('token', data.token);
        navigate('/dashboard');
      }
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
      });
      console.error(error);
    }
  };

  return (
    <>
    
      <div className="">
        <section className="min-h-screen flex flex-col items-center justify-center  mainpage  ">
          <div className='-mb-5 -mt-10'>
            <h1 className='text-[2.6rem] md:text-8xl  font-extrabold tracking-tighter text-white animated2 animatedFadeInUp fadeInUp'>Welcome to Admin Panel </h1>
          </div>
          <div className="max-w-md w-full mx-auto px-8 py-6 rounded-md shadow-2xl bg-gradient-to-tr from-meta-2 to-transparent border text-black-2 border-black-2  animated animatedFadeInUp fadeInUp ">
            <div className="flex flex-col items-center justify-center mb-5 -mt-4">
              <div>
                <img src={logo} className=' w-44' alt="" />
              </div>
              <span className="text-3xl text-black font-bold mb-4">Admin Login</span>

            </div>

            <form onSubmit={handleSubmit}>
              {/* Email input */}

              <div className="relative mb-4 text-black">
                <input

                  onChange={
                    (e) => {
                      setEmail(e.target.value)
                    }
                  }
                  type="email"
                  className="peer m-0 block h-[58px] w-full rounded border border-solid  border-black-2 bg-transparent bg-clip-padding px-3 py-4 text-base font-normal leading-tight transition duration-200 ease-linear placeholder:text-transparent focus:border-black focus:pb-[0.625rem] focus:pt-[1.625rem]  focus:outline-none peer-focus:text-black "
                  required
                  placeholder="" />
                <label
                  htmlFor="floatingInput"
                  className="pointer-events-none absolute left-0 -top-2 origin-[0_0] border border-solid border-transparent px-3 py-4  text-gray-400 transition-[opacity,_transform] duration-200 ease-linear peer-focus:-translate-y-2 peer-focus:translate-x-[0.15rem] peer-focus:scale-[0.85] peer-focus:text-black peer-[:not(:placeholder-shown)]:-translate-y-2 peer-[:not(:placeholder-shown)]:translate-x-[0.15rem] peer-[:not(:placeholder-shown)]:scale-[0.85] motion-reduce:transition-none"
                >Email address
                </label>
              </div>
              {/* password */}
              <div className="relative mb-4">
                <input
                  required
                  onChange={(e) => {
                    setPassword(e.target.value)
                  }
                  }
                  type="password"
                  className="peer m-0 block h-[58px] w-full rounded border border-solid border-black-2 bg-transparent bg-clip-padding px-3 py-4 text-base font-normal leading-tight transition duration-200 ease-linear placeholder:text-transparent focus:border-black focus:pb-[0.625rem] focus:pt-[1.625rem]  focus:outline-none peer-focus:text-black "

                  placeholder="" />

                <label
                  htmlFor="floatingInput"
                  className="pointer-events-none absolute left-0 -top-2  origin-[0_0] border border-solid border-transparent px-3 py-4  text-gray-400 transition-[opacity,_transform] duration-200 ease-linear peer-focus:-translate-y-2 peer-focus:translate-x-[0.15rem] peer-focus:scale-[0.85] peer-focus:text-black peer-[:not(:placeholder-shown)]:-translate-y-2 peer-[:not(:placeholder-shown)]:translate-x-[0.15rem] peer-[:not(:placeholder-shown)]:scale-[0.85] motion-reduce:transition-none"
                >Password
                </label>
              </div>

              {/* Login button */}
              <button
                type="submit"
                className=" w-full py-3 text-snow text-lg font-semibold rounded-lg shadow-lg  border border-black  focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50">
                Login
              </button>
            </form>
          </div>
        </section>
      </div>

    </>
  );
};

export default Login;
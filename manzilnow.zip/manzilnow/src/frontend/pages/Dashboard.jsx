
import Navbar from '../components/Navbar'
import Sidebar from '../components/Sidebar'
import Admins from '../components/Admins'
import React, { useState } from 'react'
import DashboardData from '../components/DashboardData';
import Feedback from '../components/Feedback';
import Complaints from '../components/Complaints';
import Drivers from '../components/Drivers';
import Payments from '../components/Payments';
import FairCalculations from '../components/FairCalculations';
import Passengers from '../components/Passengers';
import Settings from '../components/Settings';


export default function Dashboard() {
    const [link, setLink] = useState('dashboard');
    const [sidebarOpen, setSidebarOpen] = useState(false);

    const handleLink = () => {
        switch (link) {
            case '':
                return <DashboardData />
            case 'dashboard':
                return <DashboardData />
            case 'admins':
                return <Admins />
            case 'feedbacks':
                return <Feedback />
            case 'complaints':
                return <Complaints />
            case 'drivers':
                return <Drivers />
            case 'passengers':
                return <Passengers />
            case 'payments':
                return <Payments />
            case 'faricalculation':
                return <FairCalculations />
            case 'settings':
                return <Settings />

            default:
                break;
        }
    }


    return (

        <>
            <div className="dark:bg-boxdark-2 dark:text-bodydark">

                <div className="flex h-screen overflow-hidden">

                    <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} setLink={setLink} />

                    {/* <!-- ===== Content Area Start ===== --> */}
                    <div className="relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden">

                        <Navbar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
           
                        <div className='mt-3 sm:p-5 '>
                            <h1 className='mb-5 text-xl text-bodydark font-medium capitalize'>{link}</h1>
                            {
                                handleLink()
                            }

                        </div>
                    </div>
    
                </div>

            </div>



        </>
    )
}

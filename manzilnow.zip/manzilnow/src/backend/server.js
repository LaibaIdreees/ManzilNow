// src/backend/server.js
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const firebaseConfig = require('./firebase/firebaseConfig');
const app = express();
const admin = require('firebase-admin');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
require('dotenv').config();
app.use(bodyParser.json());
app.use(cors({ origin: 'http://localhost:3000' }));

//initialize firebase admin
const serviceAccount = require("./firebase/serviceAccountKey.json");
const reactAppRewired = require('react-app-rewired');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: firebaseConfig.databaseURL
});

const db = admin.firestore();
db.settings({
  ignoreUndefinedProperties: true,
});


// ## Add Admin ##
app.post('/addAdmin', async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    // Check for existing email (Firestore query)
    const snapshot = await db.collection('admins').where('email', '==', email).get();
    if (!snapshot.empty) {
      return res.status(400).json({ error: 'Email already in use' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // Add admin document (Firestore set)
    const newAdminRef = await db.collection('admins').add({
      name,
      email,
      password: hashedPassword,
      role,
    });

    return res.status(200).json({ message: 'Admin added successfully', id: newAdminRef.id });
  } catch (error) {
    console.error('Error adding admin:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// ## Get All Admins ##
app.get('/getAllAdmins', async (req, res) => {
  try {
    const admins = [];
    const snapshot = await db.collection('admins').get();
    snapshot.forEach((doc) => admins.push({ id: doc.id, ...doc.data() }));

    return res.status(200).json({ admins, adminCount: admins.length });
  } catch (error) {
    console.error('Error getting admins:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// ## Update Admin Info ##
app.put('/updateAdminInfo', async (req, res) => {
  try {
    const { id, role, name, email } = req.body;
    const adminRef = db.collection('admins').doc(id);
    const snapshot = await adminRef.get();

    if (!snapshot.exists) {
      return res.status(400).json({ error: 'Admin does not exist' });
    }

    const updateData = {};
    if (role) updateData.role = role;
    if (name) updateData.name = name;
    if (email) updateData.email = email;

    // Update admin document (Firestore update)
    await adminRef.update(updateData);

    return res.status(200).json({ message: 'Admin updated successfully' });
  } catch (error) {
    console.error('Error updating admin:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// ## Delete Admin ##
app.delete('/deleteAdmin', async (req, res) => {
  try {
    const { id } = req.body;
    const adminRef = db.collection('admins').doc(id);
    const snapshot = await adminRef.get();

    if (!snapshot.exists) {
      return res.status(400).json({ error: 'Admin does not exist' });
    }

    // Delete admin document (Firestore delete)
    await adminRef.delete();

    return res.status(200).json({ message: 'Admin deleted successfully' });
  } catch (error) {
    console.error('Error deleting admin:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


// ## get drivers ##
app.get('/getDrivers', async (req, res) => {
  try {
    const driversArray = [];
    const snapshot = await db.collection('driver').get();
    snapshot.forEach((doc) => {
      driversArray.push({ id: doc.id, ...doc.data() });
    });

    return res.status(200).json({ drivers: driversArray, driverCount: driversArray.length });
  } catch (error) {
    console.error('Error getting drivers:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});
// ## get driver by id ##
app.get('/getDriverById', async (req, res) => {
  try {
    const { id } = req.query;
    const snapshot = await admin.database().ref('driver').child(id).once('value');
    if (!snapshot.exists()) {
      return res.status(400).json({ error: 'Driver does not exist' });
    }
    const driver = snapshot.val();
    return res.status(200).json({ driver });
  } catch (error) {
    console.error('Error getting driver:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});
// ## getDriverPhoneNumberById ##
app.get('/getDriverPhoneNumberById', async (req, res) => {
  try {
    const { id } = req.query;
    const snapshot = await admin.database().ref('driver').child(id).once('value');
    if (!snapshot.exists()) {
      return res.status(400).json({ error: 'Driver does not exist' });
    }
    const driver = snapshot.val();
    return res.status(200).json({ phoneNumber: driver.phoneNumber });
  } catch (error) {
    console.error('Error getting driver phone number:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// ## update driver status ##
app.put('/updateDriverStatus', async (req, res) => {
  try {
      const { id, Status, reasonOfRejection: rejectedReason } = req.body;

      const snapshot = await db.collection('driver').doc(id).get();
      if (!snapshot.exists) {
          return res.status(400).json({ error: 'Driver does not exist' });
      }

      // Update driver document
      if (Status === 'Rejected') {
          
          await db.collection('driver').doc(id).update({ Status, rejectedReason });
      } else {
          // Update only status
          await db.collection('driver').doc(id).update({ Status });
      }

      return res.status(200).json({ message: 'Driver status updated successfully' });
  } catch (error) {
      console.error('Error updating driver status:', error.message);
      return res.status(500).json({ error: 'Internal server error' });
  }
});


// ## get passengers ##
app.get('/getPassengers', async (req, res) => {
  try {
    const snapshot = await db.collection('passenger').get();
    const passengers = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    const passengersArray = Object.keys(passengers).map((passengerId) => ({
      id: passengerId,
      ...passengers[passengerId],
    }));

    return res.status(200).json({ passengers: passengersArray, passengerCount: passengersArray.length });
  } catch (error) {
    console.error('Error getting passengers:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});
// ## change restrict ##
app.post('/changeRestrict', async (req, res) => {
  try {
    const { id, restricted } = req.body;
    console.log('id:', id, 'restrict:', restricted);
    const passengerRef = db.collection('passenger').doc(id);
    const snapshot = await passengerRef.get();

    if (!snapshot.exists) {
      return res.status(400).json({ error: 'Passenger does not exist' });
    }

    // change to boolean
    console.log(typeof(restricted))
    // const restricted = restrict === 'true';
    // console.log('restricted:', restricted);
    await passengerRef.update({ restricted });

    return res.status(200).json({ success: true });
  } catch (error) {
    console.error('Error changing restrict:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// ## get completed rides ##
app.get('/getCompletedRide', async (req, res) => {
  try {
    const snapshot = await db.collection('completeRide').get();
    const completedRides = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    const completedRideArray = Object.keys(completedRides).map((completedRideId) => ({
      id: completedRideId,
      ...completedRides[completedRideId],
    }));

    return res.status(200).json({ completedRide: completedRideArray, rideCount: completedRideArray.length });
  } catch (error) {
    console.error('Error getting completed rides:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});
//updateComplaintStatus
// ## updated complaint status ##
app.put('/updateComplaintStatus', async (req, res) => {
  try {
      const { id, Status } = req.body;

      const snapshot = await db.collection('support').doc(id).get();
      if (!snapshot.exists) {
          return res.status(400).json({ error: 'complaint does not exist' });
      }
 
      await db.collection('support').doc(id).update({ Status });

      return res.status(200).json({ message: 'Complaint status updated successfully' });
  } catch (error) {
      console.error('Error updating driver status:', error.message);
      return res.status(500).json({ error: 'Internal server error' });
  }
});





// ## get passengers by id ##
app.get('/getPassengerById', async (req, res) => {
  try {
    const { id } = req.query;
    // console.log('passenger id:', id);
    const snapshot = await admin.database().ref('passenger').child(id).once('value');
    if (!snapshot.exists()) {
      return res.status(400).json({ error: 'Passenger does not exist' });
    }
    const passenger = snapshot.val();
    return res.status(200).json({ passenger });
  } catch (error) {
    console.error('Error getting passenger:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// ## get complaints ##
app.get('/getComplaints', async (req, res) => {
  try {
    
    const snapshot = await db.collection('support').get();
    const complaints = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    const complaintsArray = Object.keys(complaints).map((complaintId) => ({
      id: complaintId,
      ...complaints[complaintId],
    }));

    return res.status(200).json({ complaints: complaintsArray, complaintCount: complaintsArray.length });
  } catch (error) {
    console.error('Error getting complaints:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// ## get rides ##
app.get('/getRides', async (req, res) => {
  try {
    const snapshot = await admin.database().ref('Ride').get();
    const rides = snapshot.val();
    const ridesArray = Object.keys(rides).map((rideId) => ({
      id: rideId,
      ...rides[rideId],
    }));

    return res.status(200).json({ rides: ridesArray, rideCount: ridesArray.length });
  } catch (error) {
    console.error('Error getting rides:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// ## get fair //
app.get('/getFare', async (req, res) => {
  try {
    const snapshot = await db.collection('fare').get();
    const fares = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    const faresArray = Object.keys(fares).map((fareId) => ({
      id: fareId,
      ...fares[fareId],
    }));

    return res.status(200).json({ fares: faresArray });
  } catch (error) {
    console.error('Error getting fares:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// ## update Fare price ##
app.put('/updateFare', async (req, res) => {

  try {
    const { id, 
      bikeBaseFare,
      bikeFuelConsumption,
      carBaseFare,
      carFuelConsumption,
      rickshawBaseFare,
      rickshawFuelConsumption,
      fuelPrice } = req.body;

      //convert to integer
      const bikeBaseFare_ = parseInt(bikeBaseFare);
      const bikeFuelConsumption_ = parseInt(bikeFuelConsumption);
      const carBaseFare_ = parseInt(carBaseFare);
      const carFuelConsumption_ = parseInt(carFuelConsumption);
      const rickshawBaseFare_ = parseInt(rickshawBaseFare);
      const rickshawFuelConsumption_ = parseInt(rickshawFuelConsumption);
      const fuelPrice_ = parseInt(fuelPrice);

    const fareRef = db.collection('fare').doc(id);
    const snapshot = await fareRef.get();

    if (!snapshot.exists) {
      return res.status(400).json({ error: 'Fare does not exist' });
    }
    await fareRef.update({
      bikeBaseFare: bikeBaseFare_,
      bikeFuelConsumption: bikeFuelConsumption_,
      carBaseFare: carBaseFare_,
      carFuelConsumption: carFuelConsumption_,
      rickshawBaseFare: rickshawBaseFare_,
      rickshawFuelConsumption: rickshawFuelConsumption_,
      fuelPrice: fuelPrice_

    });

    return res.status(200).json({ message: 'Fare updated successfully' });
  } catch (error) {
    console.error('Error updating fare:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


//## login ##
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if email and password are provided
    if (!email || !password) {
      return res.status(400).json({ error: 'Please provide email and password' });
    }

    // Check if email is valid
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
      return res.status(400).json({ error: 'Invalid email address' });
    }

    // Check if password length is within limits
    if (password.length < 6 || password.length > 30) {
      return res.status(400).json({ error: 'Password length should be between 6 and 30 characters' });
    }

    // Firestore query to get admin by email
    const snapshot = await db.collection('admins').where('email', '==', email).limit(1).get();

    if (snapshot.empty) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const adminDoc = snapshot.docs[0]; // Assuming only one admin with that email
    const adminData = adminDoc.data();
    const adminId = adminDoc.id;

    const isPasswordCorrect = await bcrypt.compare(password, adminData.password);
    if (!isPasswordCorrect) {
      console.log('Invalid credentials');
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const sessionToken = jwt.sign({ adminId }, process.env.JWT_SECRET);
    console.log('Admin logged in:', adminId);

    return res.status(200).json({ status: 'success', admin: adminData, id: adminId, token: sessionToken });
  } catch (error) {
    console.error('Error logging in:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
});



// ## send email ##
app.post('/sendEmail', async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log(email);
    const snapshot = await db.collection('admins').get();


    const admins = snapshot.docs.map((doc) => ({ [doc.id]: doc.data() }));
    const adminId = Object.keys(admins)[0];
    const admin_ = admins[adminId];
    let transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.MY_EMAIL,
        pass: process.env.MY_PASSWORD,
      }

    });

    let mailOptions = {
      from: process.env.MY_EMAIL,
      to: email,
      subject: 'ManzilNow Credentials',
      html: `
      <!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional //EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
<!--[if gte mso 9]>
<xml>
  <o:OfficeDocumentSettings>
    <o:AllowPNG/>
    <o:PixelsPerInch>96</o:PixelsPerInch>
  </o:OfficeDocumentSettings>
</xml>
<![endif]-->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="x-apple-disable-message-reformatting">
  <!--[if !mso]><!--><meta http-equiv="X-UA-Compatible" content="IE=edge"><!--<![endif]-->
  <title></title>
  
    <style type="text/css">
      @media only screen and (min-width: 520px) {
  .u-row {
    width: 500px !important;
  }
  .u-row .u-col {
    vertical-align: top;
  }

  .u-row .u-col-100 {
    width: 500px !important;
  }

}
@media (max-width: 520px) {
  .u-row-container {
    max-width: 100% !important;
    padding-left: 0px !important;
    padding-right: 0px !important;
  }
  .u-row .u-col {
    min-width: 320px !important;
    max-width: 100% !important;
    display: block !important;
  }
  .u-row {
    width: 100% !important;
  }
  .u-col {
    width: 100% !important;
  }
  .u-col > div {
    margin: 0 auto;
  }
}
body {
  margin: 0;
  padding: 0;
}

table,
tr,
td {
  vertical-align: top;
  border-collapse: collapse;
}

p {
  margin: 0;
}

.ie-container table,
.mso-container table {
  table-layout: fixed;
}

* {
  line-height: inherit;
}

a[x-apple-data-detectors='true'] {
  color: inherit !important;
  text-decoration: none !important;
}

table, td { color: #000000; } </style>
  
  

</head>

<body class="clean-body u_body" style="margin: 0;padding: 0;-webkit-text-size-adjust: 100%;background-color: #FFFFFF;color: #000000">
  <!--[if IE]><div class="ie-container"><![endif]-->
  <!--[if mso]><div class="mso-container"><![endif]-->
  <table style="border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;min-width: 320px;Margin: 0 auto;background-color: #FFFFFF;width:100%" cellpadding="0" cellspacing="0">
  <tbody>
  <tr style="vertical-align: top">
    <td style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
    <!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td align="center" style="background-color: #FFFFFF;"><![endif]-->
    
  
  
<div class="u-row-container" style="padding: 0px;background-color: #ffffff">
  <div class="u-row" style="margin: 0 auto;min-width: 320px;max-width: 500px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: transparent;">
    <div style="border-collapse: collapse;display: table;width: 100%;height: 100%;background-color: transparent;">
      <!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding: 0px;background-color: #ffffff;" align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:500px;"><tr style="background-color: transparent;"><![endif]-->
      
<!--[if (mso)|(IE)]><td align="center" width="500" style="background-color: #4a5899;width: 500px;padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;" valign="top"><![endif]-->
<div class="u-col u-col-100" style="max-width: 320px;min-width: 500px;display: table-cell;vertical-align: top;">
  <div style="background-color: #4a5899;height: 100%;width: 100% !important;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;">
  <!--[if (!mso)&(!IE)]><!--><div style="box-sizing: border-box; height: 100%; padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;"><!--<![endif]-->
  
<table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
  <tbody>
    <tr>
      <td style="overflow-wrap:break-word;word-break:break-word;padding:10px;font-family:arial,helvetica,sans-serif;" align="left">
        
  <!--[if mso]><table width="100%"><tr><td><![endif]-->
    <h1 style="margin: 0px; color: #ffffff; line-height: 140%; text-align: left; word-wrap: break-word; font-size: 22px; font-weight: 400;"><span><span><span>Welcome to ManzilNow</span></span></span></h1>
  <!--[if mso]></td></tr></table><![endif]-->

      </td>
    </tr>
  </tbody>
</table>

  <!--[if (!mso)&(!IE)]><!--></div><!--<![endif]-->
  </div>
</div>
<!--[if (mso)|(IE)]></td><![endif]-->
      <!--[if (mso)|(IE)]></tr></table></td></tr></table><![endif]-->
    </div>
  </div>
  </div>
  
<div class="u-row-container" style="padding: 0px;background-color: transparent">
  <div class="u-row" style="margin: 0 auto;min-width: 320px;max-width: 500px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: transparent;">
    <div style="border-collapse: collapse;display: table;width: 100%;height: 100%;background-color: transparent;">
      <!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding: 0px;background-color: transparent;" align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:500px;"><tr style="background-color: transparent;"><![endif]-->
      
<!--[if (mso)|(IE)]><td align="center" width="500" style="width: 500px;padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;" valign="top"><![endif]-->
<div class="u-col u-col-100" style="max-width: 320px;min-width: 500px;display: table-cell;vertical-align: top;">
  <div style="height: 100%;width: 100% !important;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;">
  <!--[if (!mso)&(!IE)]><!--><div style="box-sizing: border-box; height: 100%; padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;"><!--<![endif]-->
  
<table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
  <tbody>
    <tr>
      <td style="overflow-wrap:break-word;word-break:break-word;padding:10px;font-family:arial,helvetica,sans-serif;" align="left">
        
  <div style="font-size: 14px; line-height: 140%; text-align: left; word-wrap: break-word;">
    <p style="line-height: 140%;">Here Are Your Credentials:  </p>
  </div>

      </td>
    </tr>
  </tbody>
</table>

  <!--[if (!mso)&(!IE)]><!--></div><!--<![endif]-->
  </div>
</div>
<!--[if (mso)|(IE)]></td><![endif]-->
      <!--[if (mso)|(IE)]></tr></table></td></tr></table><![endif]-->
    </div>
  </div>
  </div>
  


  
  
<div class="u-row-container" style="padding: 0px;background-color: transparent">
  <div class="u-row" style="margin: 0 auto;min-width: 320px;max-width: 500px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: transparent;">
    <div style="border-collapse: collapse;display: table;width: 100%;height: 100%;background-color: transparent;">
      <!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding: 0px;background-color: transparent;" align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:500px;"><tr style="background-color: transparent;"><![endif]-->
      
<!--[if (mso)|(IE)]><td align="center" width="500" style="width: 500px;padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;" valign="top"><![endif]-->
<div class="u-col u-col-100" style="max-width: 320px;min-width: 500px;display: table-cell;vertical-align: top;">
  <div style="height: 100%;width: 100% !important;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;">
  <!--[if (!mso)&(!IE)]><!--><div style="box-sizing: border-box; height: 100%; padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;"><!--<![endif]-->
  
<table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
  <tbody>
    <tr>
      <td style="overflow-wrap:break-word;word-break:break-word;padding:10px;font-family:arial,helvetica,sans-serif;" align="left">
        
  <div style="font-size: 14px; line-height: 140%; text-align: left; word-wrap: break-word;">
    <p style="line-height: 140%;"><strong>Email:</strong>  ${email} </p>
<p style="line-height: 140%;"><strong>Password: </strong> ${password}</p>
  </div>

      </td>
    </tr>
  </tbody>
</table>

  <!--[if (!mso)&(!IE)]><!--></div><!--<![endif]-->
  </div>
</div>
<!--[if (mso)|(IE)]></td><![endif]-->
      <!--[if (mso)|(IE)]></tr></table></td></tr></table><![endif]-->
    </div>
  </div>
  </div>
  


    <!--[if (mso)|(IE)]></td></tr></table><![endif]-->
    </td>
  </tr>
  </tbody>
  </table>
  <!--[if mso]></div><![endif]-->
  <!--[if IE]></div><![endif]-->
</body>

</html>

      `,
    };

    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log(error);
        return res.status(400).json({ error: 'Invalid credentials' });
      } else {
        console.log('Email sent: ' + info.response);
        return res.status(200).json({ status: 'success', admin: admin_ });
      }
    });


    return res.status(200).json({ status: 'success', admin: admin_ });
  } catch (error) {
    console.error('Error :', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }

});

app.listen(4000, () => {

  console.log('Server is running on port 4000');

});

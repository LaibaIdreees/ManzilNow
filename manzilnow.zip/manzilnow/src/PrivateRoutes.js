import React from 'react'
import { Outlet,Navigate } from 'react-router-dom'

export default function PrivateRoutes() {
    const token = sessionStorage.getItem('token')
    if(token !== null){
        return <Outlet />
    }
    else{
        return <Navigate to="/" />
    }
}

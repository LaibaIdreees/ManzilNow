// craco.config.js
module.exports = {
  webpack: {
    configure: (webpackConfig) => {
      // Add your webpack configuration here
      webpackConfig.ignoreWarnings = [
        {
          message: /Critical dependency: the request of a dependency is an expression/,
          module: /express/
        }
      ];
      webpackConfig.resolve.fallback =
      {
        "path": require.resolve("path-browserify"),
        "os": require.resolve("os-browserify/browser"),
        "crypto": require.resolve("crypto-browserify"),
        "stream": require.resolve("stream-browserify"),
        "fs": false,
        "zlib": false,
        "http": false,
        "net": false,
        "querystring": false,
        "assert": false, // Absolute path for assert
        "util": false,   // Absolute path for util
        "url": false,
        "async_hooks": false,
      };
      return webpackConfig;
    },
  },
};
